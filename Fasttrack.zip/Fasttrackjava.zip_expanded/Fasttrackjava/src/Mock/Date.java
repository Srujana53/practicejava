package Mock;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class Date {
	public static void LocalDateTimeApi1()
	{
	 LocalDate date = LocalDate.now();
	    System.out.println("the current date is "+
	                        date); 
	    LocalTime time = LocalTime.now();
	    System.out.println("the current time is "+
	                      time); 
	    LocalDateTime current = LocalDateTime.now();
	    System.out.println("current date and time : "+
	                        current);
	  
	    Month month = current.getMonth();
	    int day = current.getDayOfMonth();
	    int seconds = current.getSecond();
	    System.out.println("Month : "+month+" day : "+
	                        day+" seconds : "+seconds);
	  
	    // printing some specified date
	    LocalDate date2 = LocalDate.of(1950,1,26);
	    System.out.println("the republic day :"+date2);
	  
	    // printing date with current time.
	    LocalDateTime specificDate = 
	        current.withDayOfMonth(24).withYear(2016);
	 
	    System.out.println("specific date with "+
	                       "current time : "+specificDate);
	    LocalDate date1 = LocalDate.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy MM dd");
	    String text = date1.format(formatter);
	    LocalDate parsedDate = LocalDate.parse(text, formatter);
	    LocalDateTime localDateTime = LocalDateTime.of(2015, Month.JANUARY, 25, 6, 30);
	    String localDateString = localDateTime.format(DateTimeFormatter.ISO_DATE);
	    localDateTime.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
	    localDateTime
	    .format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
	    .withLocale(Locale.UK));
	    
	   
	}
	 
	    // Driver code
	    public static void main(String[] args) 
	    {
	        LocalDateTimeApi1();
	    }

	

		
}
