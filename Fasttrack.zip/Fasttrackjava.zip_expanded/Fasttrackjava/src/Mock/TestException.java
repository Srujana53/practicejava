package Mock;

public class TestException {

	
		
	
		 static void validate(int age) throws InvalidAgeException
		{
			if(age<18)
			{
				throw new InvalidAgeException("invalid age");
			}
			else
			{
				System.out.println("eligible to vote");
			
			}
			
		}
		  public static void main(String[] args) {
			  try
			  {
				  validate(13);
				  
			  }
			  catch(InvalidAgeException e)
			  {
				System.out.println("caught exception");
				System.out.println("Exception occured " +e);
			  }

	}

}
