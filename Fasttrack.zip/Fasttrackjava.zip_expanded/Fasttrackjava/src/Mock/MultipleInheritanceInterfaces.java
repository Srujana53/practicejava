package Mock;

public class MultipleInheritanceInterfaces implements InterfaceDog,InterfaceLion{
	@Override
	public void roar() {
		// TODO Auto-generated method stub
		System.out.println("Lion roars");
		
	}

	@Override
	public void bark() {
		// TODO Auto-generated method stub
		System.out.println("dog barks");
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultipleInheritanceInterfaces obj=new MultipleInheritanceInterfaces();
		obj.roar();
		obj.bark();
		

	}

	

}
