package Mock;

public interface InterfaceDog {
	void bark();

}
