package com.day2;

public class OverloadingStaticInstance {
	 void add(int a,int b)
	 {
		 System.out.println(a+b);
	 }
	 void add(int a,int b,int c)
	 {
		 System.out.println(a+b+c);
	 }
	 static void display()
	 {
      System.out.println("This is static display");
			
	 }
	 static void display(String name)
	 {
      System.out.println("Name is: " +name);
			
	 }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverloadingStaticInstance obj=new OverloadingStaticInstance();
		obj.add(10,20);
		obj.add(10,20,30);
		display();
		OverloadingStaticInstance.display("Srujana");
		
}
}