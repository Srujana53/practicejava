package com.day2;

public class InstanceStaticAccess {
	int a=10;
	static int b=20;
	void show()
	{
		System.out.println("Instance method contents");	
	}
	static void display()
	{
		System.out.println("static method contents");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method 
		InstanceStaticAccess obj=new InstanceStaticAccess();
		System.out.println(obj.a);
		obj.show();
		System.out.println(b);
		InstanceStaticAccess.display();
		
		

	}

}
