package com.day2;

public class NoConstructorMain {
	
	public static void main(String[] args) {
		NoConstructor n1 = new NoConstructor();
		System.out.println(n1.getBrand());
	}

}
