package com.day4;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	StringBuffer sb=new StringBuffer("Java");
	sb.append("srujana");
/*StringBuilder sb=new StringBuilder("srujana");
sb.append("Munagala");
System.out.println(sb);*/

	
	





	}

	
}


