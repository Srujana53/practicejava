package com.day4;

public interface InterfaceDog {
	void bark();

}
