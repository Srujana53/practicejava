package com.day4;

public class Square extends AbstractShape{

	@Override
	void area() {
		// TODO Auto-generated method stub
		int side=5;
		System.out.println("Area of square is" +(side*side));
		
	}
	
	

}
