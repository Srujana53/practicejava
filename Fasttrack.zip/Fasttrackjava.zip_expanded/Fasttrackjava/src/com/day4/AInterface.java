package com.day4;

public interface AInterface {
	void show();

}
