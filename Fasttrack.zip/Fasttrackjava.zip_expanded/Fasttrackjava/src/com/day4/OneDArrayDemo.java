package com.day4;

import java.util.Scanner;

public class OneDArrayDemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter size of array: ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter elements of array: ");
		for(int i=0;i<n;i++)
		{
		arr[i]=sc.nextInt();
		}
		System.out.println("The array elemnts are: ");
		for(int i=0;i<n;i++)
		{
		System.out.println(arr[i]);
		}
		

	}

}
