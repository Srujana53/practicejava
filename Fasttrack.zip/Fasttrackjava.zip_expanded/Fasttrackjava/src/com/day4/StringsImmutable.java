package com.day4;

public class StringsImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Srujana";  
		   s.concat("Munagala");//concat() method appends the string at the end  
		   System.out.println(s);//will print Sachin because strings are immutable objects  
		 }  
		


	}


