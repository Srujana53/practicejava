package com.day4;

public class Rectangle extends AbstractShape{

	@Override
	void area() {
		// TODO Auto-generated method stub
		double l=8.9;
		double w=4.5;
		System.out.println("The area is of Rectangle is :" +(l*w));
		
	}

}
