package com.day4;

public interface InterfaceLion {
	void roar();

}
