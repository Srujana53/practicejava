package com.day4;

public class ArrayOfObjectsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeArrayOfObjects[] arr=new EmployeeArrayOfObjects[3];
		arr[0]=new EmployeeArrayOfObjects(1,"Srujana");
		arr[1]=new EmployeeArrayOfObjects(2,"Sushma");
		arr[2]=new EmployeeArrayOfObjects(3,"Srihitha");
		for(int i=0;i<3;i++)
		{
			System.out.println("Employee id: " +arr[i].id);
			System.out.println("Employee name: " +arr[i].name);
		}
		
		
		

	}

}
