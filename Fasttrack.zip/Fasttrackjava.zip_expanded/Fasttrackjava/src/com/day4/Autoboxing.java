package com.day4;

public class Autoboxing {
	public static void main(String[] args) {
		int a=10;
		double d=4.5;
		char c='A';

		Integer a1=Integer.valueOf(a);
		Double d1=Double.valueOf(d);
		Character c1=Character.valueOf(c);


	
	
	//Character c1=Character.valueOf(c);
	
	if(a1 instanceof Integer) {
	      System.out.println("An object of Integer is created.");
	    }

	    if(d1 instanceof Double) {
	      System.out.println("An object of Double is created.");
	    }
	    if(c1 instanceof Character) {
		      System.out.println("An object of Character is created.");
		    }
	  }
	}
	


