package com.day3;

public class SingleChild extends SingleParent{
	void display()

	{
		System.out.println("Child Method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingleChild obj=new SingleChild();
		obj.show();
		obj.display();
		
	}

}
