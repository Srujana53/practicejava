package com.day3;

public class HierarchicalChild1 extends HierarchicalParent{
	void show()
	 {
		 System.out.println("Child1 method");
	 }
}
