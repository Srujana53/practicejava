package com.day3;

public class MultilevelBase {
 void display()
 {
	 System.out.println("Base Method");
 }
}
