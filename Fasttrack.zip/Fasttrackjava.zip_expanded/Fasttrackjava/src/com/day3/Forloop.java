package com.day3;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10,sum=0;
		for(int i=1;i<=10;i++)
		{
			sum+=i;
		}
		System.out.print(sum);

	}

}
