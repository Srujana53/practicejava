package com.day3;

public class HierarchicalParent {
	void display()
	{
		System.out.println(" Parent Method");
	}

}
