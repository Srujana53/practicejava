package com.day3;

public class MultilevelDerived1 extends MultilevelBase{
	void show()
	 {
		 System.out.println("Derived1 method");
	 }
	}



