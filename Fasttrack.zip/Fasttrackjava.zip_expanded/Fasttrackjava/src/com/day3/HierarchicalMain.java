package com.day3;

public class HierarchicalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HierarchicalChild1 obj=new HierarchicalChild1();
		HierarchicalChild2 obj1=new HierarchicalChild2();
		obj.display();
		obj.show();
		obj1.display();
		obj1.print();
		

	}

}
