package com.day1;

public class Aprivate {
	private void display()
	{
	System.out.print("This is private method");
	}
	public static void main(String[] args) {
	}}
