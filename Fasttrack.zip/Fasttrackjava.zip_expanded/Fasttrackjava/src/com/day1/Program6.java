package com.day1;
import java.lang.*;
import java.util.Scanner;


public class Program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc= new Scanner(System.in);
		 System.out.print("Enter a string:");
	    String str=sc.nextLine();
	    String revstr="";
	    for(int i=str.length()-1;i>=0;i--)
	    {
	    	revstr+=str.charAt(i);
	    }
		
		System.out.print("Revrsed String is :"+revstr);

	}

}
