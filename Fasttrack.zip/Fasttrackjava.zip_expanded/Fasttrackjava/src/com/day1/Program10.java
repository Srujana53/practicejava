package com.day1;

import java.util.Scanner;

public class Program10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc= new Scanner(System.in);
		 System.out.print("Enter a number:");
	    int num=sc.nextInt();
	    int sum=0,digit;
		while(num!=0)
		{
			digit=num%10;
			sum+=digit;
			num=num/10;
		}
		System.out.print("The sum of didgits is :" +sum);

	}

}
