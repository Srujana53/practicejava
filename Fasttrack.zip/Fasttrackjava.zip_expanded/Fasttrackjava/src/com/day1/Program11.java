package com.day1;

import java.util.Scanner;

public class Program11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("enter first number:");
		double a=sc.nextDouble();
		System.out.print("enter second number");
		double b=sc.nextDouble();
		double avg=(a+b)/2;
		System.out.print("The average is:" +avg);

	}

}
