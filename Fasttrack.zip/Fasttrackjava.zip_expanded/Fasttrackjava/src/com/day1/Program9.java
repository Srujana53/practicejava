package com.day1;

import java.util.Scanner;

public class Program9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc= new Scanner(System.in);
		 System.out.print("Enter first number:");
	    int a=sc.nextInt();
	    System.out.print("Enter second number:");
	    int b=sc.nextInt();
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After swap first number is: "+ a);
		System.out.print("After swap second number is: "+ b);
		
		

	}

}
