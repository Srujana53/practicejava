package com.day1;

import java.util.Scanner;

public class Program17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		 System.out.print("Enter a number:");
	    int n=sc.nextInt();
		int count=0,temp=n;
		while(n!=0)
		{
			n=n/10;
			count++;
			
		}
		System.out.print("The number of digits are:" + count);
		

	}

}
