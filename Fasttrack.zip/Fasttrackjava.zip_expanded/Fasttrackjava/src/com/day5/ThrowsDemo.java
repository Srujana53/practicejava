package com.day5;
import java.io.IOException;

public class ThrowsDemo {

	
		// TODO Auto-generated method stub
		void display()throws IOException
		{
			throw new IOException("error");
		}
		public static void main(String[] args) throws IOException {
			ThrowsDemo t=new ThrowsDemo();
			t.display();
	
			
		

	}

}
