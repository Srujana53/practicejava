package com.day5;

import java.util.Iterator;
import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> s=new Stack<String>();
		s.push("My");
		s.push("name");
		s.push("is");
		s.push("Srujana");
		System.out.println(s);
		Iterator<String> itr=s.iterator();
		while(itr.hasNext())
			{
			System.out.print(itr.next() + " ");
			}
		s.pop();
		itr=s.iterator();
		System.out.println();
		while(itr.hasNext())
		{
			
		System.out.print(itr.next() + " ");
		}

	}

}
