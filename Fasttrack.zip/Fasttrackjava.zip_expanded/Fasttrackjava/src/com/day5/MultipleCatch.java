package com.day5;

public class MultipleCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			int[] a=new int[5];
			a[6]=5/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("ArrayIndexoutofBounds Exception");
		}
		catch(Exception e)
		{
			System.out.println("Parent exception occurs");
		}
		System.out.println("rest of the code");

	}

}
