package com.day5;
@FunctionalInterface
public interface FunctionalInterfaceDemo {

	public void show();
}
