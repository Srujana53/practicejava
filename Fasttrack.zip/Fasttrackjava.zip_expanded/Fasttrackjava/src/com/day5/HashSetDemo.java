package com.day5;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hs=new HashSet<String>();
		hs.add("My");
		hs.add("Name");
		hs.add("is");
		hs.add("Srujana");
		Iterator<String> itr=hs.iterator();
		while(itr.hasNext())
		{
			System.out.print(itr.next() + " ");
		}

	}

}
