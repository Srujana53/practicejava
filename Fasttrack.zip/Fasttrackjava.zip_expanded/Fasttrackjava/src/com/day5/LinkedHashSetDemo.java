package com.day5;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<String> lhs=new LinkedHashSet<String>();
		lhs.add("My");
		lhs.add("name");
		lhs.add("is");
		lhs.add("Srujana");
		Iterator<String> itr=lhs.iterator();
		while(itr.hasNext())
		{
			System.out.print(itr.next() + " ");
		}

	}

}
