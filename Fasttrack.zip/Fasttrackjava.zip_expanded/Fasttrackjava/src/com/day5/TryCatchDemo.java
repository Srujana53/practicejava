package com.day5;

public class TryCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		int a=5/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code..");
		

	}

}
