package com.day5;

public class NestedTryBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			try
			{
			int a=5/0;
		    }
			catch(ArithmeticException e)
			{
				System.out.println(e);
			}
			try
			{
				int[] a=new int[5];
				a[6]=10;
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println(" Array out of bounds");
			}
		}catch(Exception e)
		{
			System.out.println("Handled...");
		}
	finally
	{
		System.out.println("it always excecutes");
	}

			
	}

}
