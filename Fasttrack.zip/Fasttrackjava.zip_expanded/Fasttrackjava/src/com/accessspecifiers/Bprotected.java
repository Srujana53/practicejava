package com.accessspecifiers;
import com.day1.*;

public class Bprotected extends Aprotected
{
	public static void main(String args[])
	{
		Bprotected obj=new Bprotected();
		obj.display();
		
	}
	

}
