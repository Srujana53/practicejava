package com.oop2.inheritence;

public class Animal {
	
	String name;
	public void eat() {
		System.out.println("I can eat");
	}

}
